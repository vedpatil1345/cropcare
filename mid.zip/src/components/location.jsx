import React from 'react'

const location = () => {

  return (
    <>
      
    </>
  )
}

export default location
