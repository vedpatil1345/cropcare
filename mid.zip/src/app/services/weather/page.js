import Weather from "@/components/pages/Weather";

export default function page() {
  return (
    <div>
      <Weather />
    </div>
  );
}
