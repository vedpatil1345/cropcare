import Schemes from '@/components/pages/Scheme'
import React from 'react'

const page = () => {
  return (
    <div>
      <Schemes/>
    </div>
  )
}

export default page
