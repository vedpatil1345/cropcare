import MarketInsights from "@/components/pages/MarketInsights";

export default function Home() {
  return (
    <>
      <MarketInsights />
    </>
  );
}
