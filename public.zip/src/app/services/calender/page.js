import Calender from '@/components/pages/Calender';
const page = () => {
    return (
        <div>
           <Calender/>
        </div>
    );
}

export default page;