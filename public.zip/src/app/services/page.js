import Services from "@/components/pages/Services";


export default function Home() {
  return (
    <>
      <Services />
    </>
  );
}
