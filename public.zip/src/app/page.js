import Hero from '@/components/pages/Hero'


export default function Home() {
  return (
    <>
      <Hero/>
    </>
  );
}
